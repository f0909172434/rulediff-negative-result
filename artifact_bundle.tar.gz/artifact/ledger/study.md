# mlsys2027_rulediff_local_v3

## Purpose
Formal RuleDiff development study on repaired local compute using one physical scratch root for both ledger and execution. Run the tracked word-Jaccard baseline first, then IDF-weighted cosine, complete exactly 12 scientific development runs within four hours, and freeze the best result before any private-test evaluation.

## Objective
maximize `dev_stratified_macro_f1`

## Rules
- Target: local, 1 run at a time
- Kill criteria: 20 minutes
- Budget: maxRuns 12, maxHours 4, runMinutes 20
- Code review before the baseline: no

## State
- Status: concluded
- Baseline: Frozen word-Jaccard baseline (dev_stratified_macro_f1 0.57)
- Best: IDF cosine threshold 0.20 (dev_stratified_macro_f1 0.99193)
- Driver turns: 0

## Conclusion
Completed all 12 authorized scientific development runs on local compute. The tracked word-Jaccard/0.05 baseline scored 0.570001087966944. The prioritized IDF cosine/0.15 candidate reproduced at 0.9068179557529318. The final best is IDF-weighted word cosine at threshold 0.20 with dev_stratified_macro_f1=0.9919311457772997, one false invalidation, zero stale false negatives, and a +0.42193005781035564 absolute gain over baseline. Threshold 0.25 degraded to 0.9017099939931748, bracketing the tested development optimum. Freeze method=word_idf_cosine, threshold=0.20, char_n=4, alpha=0.5 for the next confirmatory private-test stage. Development evidence is based on only eight source-clause blocks and must not be generalized before that held-out evaluation.

## The loop
1. Pick the highest-priority queued idea (ideas.md).
2. Implement it in the training script; start one run per idea with the study tool.
3. When the run ends, read the metric, decide keep or revert, and record the verdict with its analysis.
4. Queue the ideas the result suggests. Repeat until the budget or target is reached.
