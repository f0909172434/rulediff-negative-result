import json
import unittest
from pathlib import Path

from eval_core import binary_macro_f1, block_bootstrap_ci, evaluate


ROOT = Path(__file__).resolve().parents[1]


class EvaluationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.artifacts = json.loads((ROOT / "data/development/artifacts.json").read_text(encoding="utf-8"))
        cls.transitions = json.loads((ROOT / "data/development/dev_transitions.json").read_text(encoding="utf-8"))

    def test_fixed_counts_and_balance(self) -> None:
        self.assertEqual(len(self.artifacts), 18)
        self.assertEqual(len(self.transitions), 24)
        self.assertEqual({shift: sum(row["shift_class"] == shift for row in self.transitions) for shift in {row["shift_class"] for row in self.transitions}}, {"tightened_prohibition": 8, "relaxed_permission": 8, "conditional_exception": 8})
        self.assertEqual(len({row["source_clause_sha256"] for row in self.transitions}), 8)

    def test_metric_hand_case(self) -> None:
        rows = [
            {"truth": True, "prediction": True},
            {"truth": True, "prediction": False},
            {"truth": False, "prediction": False},
            {"truth": False, "prediction": True},
        ]
        self.assertEqual(binary_macro_f1(rows), 0.5)

    def test_evaluation_covers_every_pair_and_stratum(self) -> None:
        result = evaluate(self.artifacts, self.transitions, "word_jaccard", 0.05, 4, 0.5)
        self.assertEqual(result["pairs"], 18 * 24)
        self.assertEqual(result["transitions"], 24)
        observed = {f"{row['shift_class']}|fanout={len(row['affected_artifact_ids'])}" for row in self.transitions}
        self.assertEqual(set(result["stratum_macro_f1"]), observed)

    def test_no_private_data_path_in_evaluator(self) -> None:
        source = (ROOT / "code/train.py").read_text(encoding="utf-8") + (ROOT / "code/eval_core.py").read_text(encoding="utf-8")
        self.assertNotIn("evaluation_private", source)
        self.assertNotIn("test_labels", source)

    def test_rows_retain_source_blocks_and_bootstrap_is_finite(self) -> None:
        result = evaluate(self.artifacts, self.transitions, "word_jaccard", 0.05, 4, 0.5)
        self.assertEqual(len({row["source_clause_sha256"] for row in result["rows"]}), 8)
        lower, upper = block_bootstrap_ci(result["rows"], draws=100)
        self.assertLessEqual(lower, upper)


if __name__ == "__main__":
    unittest.main()
