from __future__ import annotations

import csv
import hashlib
import json
import math
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "code"))
from eval_core import block_bootstrap_ci, evaluate  # noqa: E402


def load(path: Path) -> object:
    return json.loads(path.read_text(encoding="utf-8"))


def check(name: str, condition: bool) -> None:
    if not condition:
        raise AssertionError(name)
    print(f"PASS {name}")


def close(left: float, right: float, tolerance: float = 1e-12) -> bool:
    return math.isclose(float(left), float(right), rel_tol=0.0, abs_tol=tolerance)


def verify_manifest() -> None:
    manifest = ROOT / "MANIFEST.sha256"
    check("checksum manifest exists", manifest.is_file())
    recorded: dict[str, str] = {}
    for line in manifest.read_text(encoding="utf-8").splitlines():
        digest, relative = line.split("  ", 1)
        recorded[relative] = digest
    actual_files = {
        path.relative_to(ROOT).as_posix()
        for path in ROOT.rglob("*")
        if path.is_file() and path.name != "MANIFEST.sha256" and "__pycache__" not in path.parts
    }
    check("manifest file coverage", set(recorded) == actual_files)
    for relative, expected in recorded.items():
        actual = hashlib.sha256((ROOT / relative).read_bytes()).hexdigest()
        check(f"sha256 {relative}", actual == expected)


def verify_unit_tests() -> None:
    suite = unittest.defaultTestLoader.discover(str(ROOT / "tests"))
    result = unittest.TextTestRunner(verbosity=1).run(suite)
    check("five evaluator unit tests", result.wasSuccessful() and result.testsRun == 5)


def verify_development() -> None:
    manifest = load(ROOT / "run_manifest.json")
    assert isinstance(manifest, dict)
    runs = manifest["runs"]
    check("12-run machine manifest", len(runs) == 12)
    with (ROOT / "ledger/results.tsv").open(encoding="utf-8", newline="") as handle:
        ledger = list(csv.DictReader(handle, delimiter="\t"))
    check("12 finished ledger rows", len(ledger) == 12 and all(row["status"] == "finished" for row in ledger))

    artifacts = load(ROOT / "data/development/artifacts.json")
    transitions = load(ROOT / "data/development/dev_transitions.json")
    assert isinstance(artifacts, list) and isinstance(transitions, list)
    for run in runs:
        saved = load(ROOT / "results/development" / run["output"])
        assert isinstance(saved, dict)
        config = {name: run[name] for name in ("method", "threshold", "char_n", "alpha")}
        check(f"config {run['output']}", saved["config"] == config)
        recomputed = evaluate(artifacts, transitions, **config)
        for key in ("pairs", "transitions", "stale_false_negatives", "false_invalidations", "stratum_macro_f1"):
            check(f"development {run['output']} {key}", recomputed[key] == saved[key])
        check(f"development {run['output']} score", close(recomputed["stratified_macro_f1"], run["expected"]))
        expected_predictions = [(row["transition_id"], row["artifact_id"], row["prediction"]) for row in saved["rows"]]
        actual_predictions = [(row["transition_id"], row["artifact_id"], row["prediction"]) for row in recomputed["rows"]]
        check(f"development {run['output']} decisions", actual_predictions == expected_predictions)
        interval = list(block_bootstrap_ci(recomputed["rows"], draws=2000, seed=20260929))
        check(f"development {run['output']} CI", all(close(a, b) for a, b in zip(interval, saved["bootstrap_95_interval"])))


def verify_private() -> None:
    artifacts = load(ROOT / "data/private/artifacts.json")
    public = load(ROOT / "data/private/test_inputs.json")
    private = load(ROOT / "data/private/private_labels.json")
    saved = load(ROOT / "results/private/private_result.json")
    winner = load(ROOT / "results/development/word_idf_cosine_t020.json")
    assert all(isinstance(value, dict) for value in (public, private, saved, winner))
    labels = private["labels"]
    transitions = [
        {**row, "affected_artifact_ids": labels[row["transition_id"]]["affected_artifact_ids"]}
        for row in public["transitions"]
    ]
    recomputed = evaluate(artifacts, transitions, **winner["config"])
    for key in ("pairs", "transitions", "stratum_macro_f1", "stale_false_negatives", "false_invalidations"):
        check(f"private aggregate {key}", recomputed[key] == saved[key])
    # Python 3.12+ sum() uses compensated summation, so float means can move by one ulp from the 3.11 record.
    for key in ("pooled_macro_f1", "stratified_macro_f1"):
        check(f"private aggregate {key}", close(recomputed[key], saved[key]))
    interval = list(block_bootstrap_ci(recomputed["rows"], draws=2000, seed=20260929))
    check("private bootstrap interval", len(interval) == len(saved["bootstrap_95_interval"]) and all(close(a, b) for a, b in zip(interval, saved["bootstrap_95_interval"])))
    check("private error counts", saved["stale_false_negatives"] == 14 and saved["false_invalidations"] == 3)
    high_fanout = [row for row in recomputed["rows"] if row["stratum"] == "tightened_prohibition|fanout=5"]
    check("high-fanout confusion", len(high_fanout) == 12 and sum(row["truth"] and not row["prediction"] for row in high_fanout) == 5)


def verify_sources() -> None:
    dev = load(ROOT / "data/development/dev_transitions.json")
    private = load(ROOT / "data/private/test_inputs.json")
    assert isinstance(dev, list) and isinstance(private, dict)
    airline = (ROOT / "provenance/tau_bench_airline_policy.md").read_text(encoding="utf-8")
    retail = (ROOT / "provenance/tau_bench_retail_policy.md").read_text(encoding="utf-8")
    for name, transitions, source in (("development", dev, airline), ("private", private["transitions"], retail)):
        for row in transitions:
            digest = hashlib.sha256(row["old_clause"].encode("utf-8")).hexdigest()
            check(f"{name} source hash {row['transition_id']}", digest == row["source_clause_sha256"])
            check(f"{name} source text {row['transition_id']}", row["old_clause"] in source)


def main() -> None:
    check("Python 3.11+", sys.version_info >= (3, 11))
    excluded = ("compromised_v0", "modal_study", "local_v1")
    packaged = [path.as_posix() for path in ROOT.rglob("*")]
    check("excluded studies absent", not any(token in path for token in excluded for path in packaged))
    verify_manifest()
    verify_unit_tests()
    verify_development()
    verify_private()
    verify_sources()
    print("ARTIFACT_VERIFICATION_PASS")


if __name__ == "__main__":
    main()
