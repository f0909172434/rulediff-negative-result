from __future__ import annotations

import argparse
import json
from pathlib import Path

from eval_core import block_bootstrap_ci, evaluate


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate one RuleDiff development configuration.")
    parser.add_argument("--method", choices=("word_jaccard", "word_idf_cosine", "char_jaccard", "hybrid"), required=True)
    parser.add_argument("--threshold", type=float, required=True)
    parser.add_argument("--char-n", type=int, default=4)
    parser.add_argument("--alpha", type=float, default=0.5)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if not 0.0 <= args.threshold <= 1.0 or not 0.0 <= args.alpha <= 1.0 or not 2 <= args.char_n <= 8:
        raise ValueError("configuration outside frozen bounds")
    root = Path(__file__).resolve().parents[1]
    artifacts = json.loads((root / "data/development/artifacts.json").read_text(encoding="utf-8"))
    transitions = json.loads((root / "data/development/dev_transitions.json").read_text(encoding="utf-8"))
    result = evaluate(artifacts, transitions, args.method, args.threshold, args.char_n, args.alpha)
    lower, upper = block_bootstrap_ci(result["rows"])
    result["bootstrap_95_interval"] = [lower, upper]
    result["split"] = "development"
    result["config"] = {"method": args.method, "threshold": args.threshold, "char_n": args.char_n, "alpha": args.alpha}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    temporary = args.output.with_suffix(args.output.suffix + ".tmp")
    temporary.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    temporary.replace(args.output)
    metric = float(result["stratified_macro_f1"])
    try:
        import openscience_track as track
        track.init(config=result["config"])
        track.log({"dev_stratified_macro_f1": metric}, step=1)
        track.summary["dev_stratified_macro_f1"] = metric
        track.finish()
    except ImportError:
        pass
    print(f"dev_stratified_macro_f1={metric:.9f}")
    print(f"bootstrap_95_interval=[{lower:.9f}, {upper:.9f}]")


if __name__ == "__main__":
    main()
