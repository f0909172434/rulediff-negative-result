from __future__ import annotations

import argparse
import json
import sys
from collections import defaultdict
from pathlib import Path


def confusion(rows: list[dict[str, object]]) -> dict[str, int]:
    return {
        "true_positives": sum(bool(row["truth"]) and bool(row["prediction"]) for row in rows),
        "true_negatives": sum(not bool(row["truth"]) and not bool(row["prediction"]) for row in rows),
        "false_positives": sum(not bool(row["truth"]) and bool(row["prediction"]) for row in rows),
        "false_negatives": sum(bool(row["truth"]) and not bool(row["prediction"]) for row in rows),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Post-hoc failure analysis of the terminal G3 packet.")
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)

    study = args.root / "autoresearch/mlsys2027_rulediff_local_v3"
    private_dir = args.root / "evaluation_private/retail_v1"
    sys.path.insert(0, str(study.resolve()))
    from eval_core import evaluate

    artifacts = json.loads((private_dir / "artifacts.json").read_text(encoding="utf-8"))
    inputs = json.loads((private_dir / "test_inputs.json").read_text(encoding="utf-8"))["transitions"]
    labels = json.loads((private_dir / "private_labels.json").read_text(encoding="utf-8"))["labels"]
    config = json.loads((study / "outputs/word_idf_cosine_t020.json").read_text(encoding="utf-8"))["config"]
    transitions = [
        {**row, "affected_artifact_ids": labels[row["transition_id"]]["affected_artifact_ids"]}
        for row in inputs
    ]
    result = evaluate(artifacts, transitions, **config)
    by_stratum: dict[str, list[dict[str, object]]] = defaultdict(list)
    by_transition: dict[str, list[dict[str, object]]] = defaultdict(list)
    for row in result["rows"]:
        by_stratum[str(row["stratum"])].append(row)
        by_transition[str(row["transition_id"])].append(row)
    output = {
        "analysis_role": "post-hoc diagnosis; does not replace the terminal blind aggregate",
        "overall": confusion(result["rows"]),
        "by_stratum": {name: confusion(rows) for name, rows in sorted(by_stratum.items())},
        "by_transition": {name: confusion(rows) for name, rows in sorted(by_transition.items())},
        "false_negative_pairs": [
            {"transition_id": row["transition_id"], "artifact_id": row["artifact_id"], "score": row["score"], "stratum": row["stratum"]}
            for row in result["rows"]
            if bool(row["truth"]) and not bool(row["prediction"])
        ],
        "false_positive_pairs": [
            {"transition_id": row["transition_id"], "artifact_id": row["artifact_id"], "score": row["score"], "stratum": row["stratum"]}
            for row in result["rows"]
            if not bool(row["truth"]) and bool(row["prediction"])
        ],
    }
    temporary = args.output.with_suffix(args.output.suffix + ".tmp")
    temporary.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    temporary.replace(args.output)
    print(json.dumps(output["overall"], sort_keys=True))
    print(json.dumps(output["by_stratum"], sort_keys=True))


if __name__ == "__main__":
    main()
