# mlsys2027_rulediff_local_v3: ideas

Objective: maximize `dev_stratified_macro_f1`. Ranked by manual priority, then expected value. Rendered by OpenScience from the study record; edit through the study tool.

#
- idea_id: `idea_0eb87cd6e001gDgMb2PEzBfnl8`
- Title: Frozen word-Jaccard baseline
- Description: Evaluate stopword-filtered word-set Jaccard at threshold 0.05 on the frozen development benchmark.
- EV Improvement: 0
- Why: Provides the required simplest lexical reference before any candidate run.
- Status: kept
- Config: `{"method":"word_jaccard","threshold":0.05,"char_n":4,"alpha":0.5}`
- Created: 2026-09-29 04:59
- Run: 2026-09-29 04:59 - 2026-09-29 04:59
- Result: dev_stratified_macro_f1 0.57; run `exp_0eb87e361001KRg2yArk50b3on`, job `b8461338-ce6`
- Analysis: The frozen word-Jaccard configuration completed locally and logged dev_stratified_macro_f1=0.570001087966944 on 432 development pairs. The delivered output reports a source-clause block-bootstrap 95% interval of [0.531291255, 0.595253807].
- Conclusion: Valid formal tracked baseline. Keep as the reference for all subsequent development runs.
#

#
- idea_id: `idea_0eb87cd6e002fKF1SHlfRJA5nV`
- Title: IDF-weighted word cosine
- Description: Evaluate IDF-weighted word cosine at threshold 0.15 on the identical frozen development benchmark.
- EV Improvement: 0.3368
- Why: This was the strongest pre-study diagnostic and tests whether rare operational terms identify dependency edges better than uniform overlap.
- Status: kept
- Config: `{"method":"word_idf_cosine","threshold":0.15,"char_n":4,"alpha":0.5}`
- Created: 2026-09-29 04:59
- Run: 2026-09-29 04:59 - 2026-09-29 04:59
- Result: dev_stratified_macro_f1 0.90682 (+0.33682 vs baseline); run `exp_0eb885399001svn3tAWWQTzGWP`, job `cc61473b-fc7`
- Analysis: IDF-weighted word cosine at threshold 0.15 completed and logged dev_stratified_macro_f1=0.9068179557529318, an absolute improvement of 0.33681686778598774 over the tracked word-Jaccard baseline. The delivered output reports block-bootstrap 95% interval [0.877672131, 0.949575472].
- Conclusion: The pre-prioritized diagnostic winner reproduces as a formal tracked 0.90+ result and becomes the current best.
#

#
- idea_id: `idea_0eb87cd6e003Q9Hz5e0zGBDtvj`
- Title: Hybrid lexical similarity
- Description: Combine IDF cosine and character 4-gram overlap with alpha 0.7 and threshold 0.10.
- EV Improvement: 0.19
- Why: Tests whether subword overlap recovers paraphrastic dependencies missed by weighted words.
- Status: reverted
- Config: `{"method":"hybrid","threshold":0.1,"char_n":4,"alpha":0.7}`
- Created: 2026-09-29 04:59
- Run: 2026-09-29 05:00 - 2026-09-29 05:00
- Result: dev_stratified_macro_f1 0.75897 (+0.18897 vs baseline); run `exp_0eb88c1de001MaXu6ZNU43YxEp`, job `636ffa08-63c`
- Analysis: Hybrid alpha 0.7 at threshold 0.10 logged 0.7589716908102467, above baseline by 0.1889706028433027 but below the current IDF-only best by 0.1478462649426851.
- Conclusion: Reject as best configuration; character overlap dilutes the stronger IDF signal at this setting.
#

#
- idea_id: `idea_0eb87cd6e004pa5kr78v6wFcGU`
- Title: Character four-gram overlap
- Description: Evaluate character 4-gram Jaccard at threshold 0.05.
- EV Improvement: -0.24
- Why: Orthogonal lexical representation tests morphology and minor paraphrase robustness.
- Status: reverted
- Config: `{"method":"char_jaccard","threshold":0.05,"char_n":4,"alpha":0.5}`
- Created: 2026-09-29 04:59
- Run: 2026-09-29 05:00 - 2026-09-29 05:00
- Result: dev_stratified_macro_f1 0.32937 (-0.24063 vs baseline); run `exp_0eb892ad9001YjkdheTkHIsndZ`, job `8793a9e2-b7e`
- Analysis: Character 4-gram Jaccard at threshold 0.05 logged 0.32937486700401225, 0.2406262209629318 below baseline and 0.5774430887489196 below the current best.
- Conclusion: Reject; standalone character overlap is unsuitable for this benchmark at the diagnostic setting.
#

#
- idea_id: `idea_0eb87cd6e005i1UcyMa7WbPpbP`
- Title: IDF cosine lower threshold 0.10
- Description: Lower the IDF cosine decision threshold from 0.15 to 0.10.
- EV Improvement: -0.03
- Why: Measures the stale-dependency recall versus false-invalidation tradeoff below the diagnostic winner.
- Status: reverted
- Config: `{"method":"word_idf_cosine","threshold":0.1,"char_n":4,"alpha":0.5}`
- Created: 2026-09-29 04:59
- Run: 2026-09-29 05:00 - 2026-09-29 05:01
- Result: dev_stratified_macro_f1 0.75955 (+0.18955 vs baseline); run `exp_0eb8990e3001PvR0JZRqH29TDO`, job `f28e564e-46d`
- Analysis: IDF cosine threshold 0.10 logged 0.7595470250730748, improving on baseline but trailing threshold 0.15 by 0.147270930679857.
- Conclusion: Reject as best; the lower threshold causes enough false invalidation pressure to erase much of the IDF gain.
#

#
- idea_id: `idea_0eb87cd6e006WeYGEcqEy9Gvig`
- Title: IDF cosine threshold 0.12
- Description: Evaluate IDF cosine with a near-lower threshold of 0.12.
- EV Improvement: 0.005
- Why: Provides local threshold sensitivity between the broad 0.10 setting and diagnostic winner 0.15.
- Status: reverted
- Config: `{"method":"word_idf_cosine","threshold":0.12,"char_n":4,"alpha":0.5}`
- Created: 2026-09-29 04:59
- Run: 2026-09-29 05:01 - 2026-09-29 05:01
- Result: dev_stratified_macro_f1 0.80944 (+0.23944 vs baseline); run `exp_0eb89fab8001AAxIMInI66Cznz`, job `49dc95fb-ce8`
- Analysis: IDF cosine threshold 0.12 logged 0.8094434257210263, 0.2394423377540823 above baseline but 0.09737453003190544 below threshold 0.15.
- Conclusion: Reject as best; performance rises toward 0.15 but remains materially lower at 0.12.
#

#
- idea_id: `idea_0eb87cd6e007vpY7xAZ2hLBnWs`
- Title: IDF cosine threshold 0.18
- Description: Evaluate IDF cosine at threshold 0.18.
- EV Improvement: 0.005
- Why: Tests whether removing low-confidence invalidations improves macro-F1 without introducing excessive stale false negatives.
- Status: kept
- Config: `{"method":"word_idf_cosine","threshold":0.18,"char_n":4,"alpha":0.5}`
- Created: 2026-09-29 04:59
- Run: 2026-09-29 05:01 - 2026-09-29 05:02
- Result: dev_stratified_macro_f1 0.98637 (+0.41637 vs baseline); run `exp_0eb8a768e0012Lpp7BsgP6ahlI`, job `b00a6ec6-879`
- Analysis: IDF cosine threshold 0.18 logged 0.9863730170139832, improving on threshold 0.15 by 0.07955506126105139 and on baseline by 0.4163719290470391. The delivered output reports block-bootstrap 95% interval [0.9767732510404574, 0.9919311457772997] and two false invalidations.
- Conclusion: New tracked best; keep threshold 0.18 while testing higher thresholds for the precision-recall boundary.
#

#
- idea_id: `idea_0eb87cd6e008D3HYMf46oogz1G`
- Title: IDF cosine threshold 0.20
- Description: Evaluate IDF cosine at threshold 0.20.
- EV Improvement: -0.01
- Why: Extends the upper-side threshold sensitivity analysis at a policy-relevant round cutoff.
- Status: kept
- Config: `{"method":"word_idf_cosine","threshold":0.2,"char_n":4,"alpha":0.5}`
- Created: 2026-09-29 04:59
- Run: 2026-09-29 05:02 - 2026-09-29 05:03
- Result: dev_stratified_macro_f1 0.99193 (+0.42193 vs baseline); run `exp_0eb8b0ec8001KCwcHmOBPXQCYI`, job `f100cdf2-a06`
- Analysis: IDF cosine threshold 0.20 logged 0.9919311457772997, improving on threshold 0.18 by 0.005558128763316517 and baseline by 0.42193005781035564. It has one false invalidation and zero stale false negatives. The block-bootstrap interval is degenerate at the point estimate because the sole error pattern is invariant under the available source-block resamples; with only eight source clauses this must not be read as zero population uncertainty.
- Conclusion: New tracked development best; keep threshold 0.20 pending the conservative 0.25 boundary test.
#

#
- idea_id: `idea_0eb87cd6f001rVSCXuYIUmSVWf`
- Title: IDF cosine threshold 0.25
- Description: Evaluate a conservative IDF cosine threshold of 0.25.
- EV Improvement: -0.06
- Why: Stress-tests whether precision gains can compensate for reduced dependency recall.
- Status: reverted
- Config: `{"method":"word_idf_cosine","threshold":0.25,"char_n":4,"alpha":0.5}`
- Created: 2026-09-29 04:59
- Run: 2026-09-29 05:03 - 2026-09-29 05:03
- Result: dev_stratified_macro_f1 0.90171 (+0.33171 vs baseline); run `exp_0eb8b903d001BtKS4XFEETEVMy`, job `0d7f9b02-f7d`
- Analysis: IDF cosine threshold 0.25 logged 0.9017099939931748, still 0.3317089060262307 above baseline but 0.09022115178412493 below threshold 0.20.
- Conclusion: Reject as best; the conservative threshold crosses the optimum and introduces excessive stale false negatives.
#

#
- idea_id: `idea_0eb87cd6f0024hn428iPF3zVTo`
- Title: Word-Jaccard threshold 0.10
- Description: Evaluate the baseline representation with threshold raised from 0.05 to 0.10.
- EV Improvement: 0.08
- Why: Separates representation gains from simple baseline threshold calibration.
- Status: reverted
- Config: `{"method":"word_jaccard","threshold":0.1,"char_n":4,"alpha":0.5}`
- Created: 2026-09-29 04:59
- Run: 2026-09-29 05:03 - 2026-09-29 05:03
- Result: dev_stratified_macro_f1 0.85943 (+0.28943 vs baseline); run `exp_0eb8c0ba4001p2z8myNqIxdP54`, job `5fb3ed1a-cb5`
- Analysis: Word Jaccard threshold 0.10 logged 0.8594331893088106, a 0.2894321013418666 gain over the frozen 0.05 baseline but 0.13249795646848905 below the IDF/0.20 best.
- Conclusion: Reject as best. Threshold calibration explains part, but not all, of IDF cosine's advantage.
#

#
- idea_id: `idea_0eb87cd6f003uNDISnVGDVBu3e`
- Title: IDF-heavy hybrid
- Description: Evaluate hybrid similarity at threshold 0.15 with alpha 0.8 on IDF cosine.
- EV Improvement: -0.01
- Why: Tests a mostly-IDF model with a small character-overlap contribution at the IDF decision scale.
- Status: reverted
- Config: `{"method":"hybrid","threshold":0.15,"char_n":4,"alpha":0.8}`
- Created: 2026-09-29 04:59
- Run: 2026-09-29 05:04 - 2026-09-29 05:04
- Result: dev_stratified_macro_f1 0.9207 (+0.3507 vs baseline); run `exp_0eb8c6c7d001JPZLEJ0SsHSixq`, job `32987774-4af`
- Analysis: The IDF-heavy hybrid logged 0.9206986831420901, 0.3506975951751461 above baseline but 0.07123246263520955 below IDF cosine threshold 0.20.
- Conclusion: Reject as best; even a small character-overlap component does not improve the calibrated IDF-only method.
#

#
- idea_id: `idea_0eb87cd6f004Kmx609T4b4osjN`
- Title: Character trigram overlap
- Description: Evaluate character 3-gram Jaccard at threshold 0.05.
- EV Improvement: -0.16
- Why: Tests whether shorter character units improve coverage over the weak 4-gram diagnostic.
- Status: reverted
- Config: `{"method":"char_jaccard","threshold":0.05,"char_n":3,"alpha":0.5}`
- Created: 2026-09-29 04:59
- Run: 2026-09-29 05:04 - 2026-09-29 05:04
- Result: dev_stratified_macro_f1 0.1255 (-0.44451 vs baseline); run `exp_0eb8ccac5001ny9OOqklXGsgwz`, job `dc30a2c9-ce5`
- Analysis: Character trigram Jaccard at threshold 0.05 logged 0.12549526335365427, 0.4445058246132898 below baseline and 0.8664358824236454 below the best.
- Conclusion: Reject; shortening character units worsens the already weak standalone character representation.
#
