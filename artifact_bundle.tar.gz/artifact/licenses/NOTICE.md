# Third-Party Notice

The policy snapshots in `provenance/` originate from tau-bench by Sierra and are redistributed under the MIT license in `TAU_BENCH_LICENSE`. The development oracle records originate from IBM ToolGuard commit `20e21db4c275d79f8d7bf33ffb985d0b45f786f5` and are redistributed under Apache License 2.0 in `TOOLGUARD_LICENSE`. Exact source URLs and recorded hashes are in `SOURCES.json`.

The tau-bench snapshots were retrieved from mutable `main` URLs on 2026-09-29; their exact bytes are preserved and hashed, but the historical upstream commit was not recorded. This limits provenance resolution, not local repeatability.
