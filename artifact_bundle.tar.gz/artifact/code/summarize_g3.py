from __future__ import annotations

import argparse
import json
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser(description="Summarize the completed G3 aggregate without rerunning evaluation.")
    parser.add_argument("--development", type=Path, required=True)
    parser.add_argument("--private", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    development = json.loads(args.development.read_text(encoding="utf-8"))
    private = json.loads(args.private.read_text(encoding="utf-8"))
    dev_score = float(development["stratified_macro_f1"])
    private_score = float(private["stratified_macro_f1"])
    absolute_change = private_score - dev_score
    summary = {
        "schema_version": 1,
        "evaluation_protocol": "single blind run with frozen G2 winner",
        "frozen_config": private["candidate_config"],
        "development": {
            "transitions": int(development["transitions"]),
            "pairs": int(development["pairs"]),
            "stratified_macro_f1": dev_score,
            "pooled_macro_f1": float(development["pooled_macro_f1"]),
            "bootstrap_95_interval": development["bootstrap_95_interval"],
        },
        "private_test": {
            "transitions": int(private["transitions"]),
            "pairs": int(private["pairs"]),
            "stratified_macro_f1": private_score,
            "pooled_macro_f1": float(private["pooled_macro_f1"]),
            "bootstrap_95_interval": private["bootstrap_95_interval"],
            "stale_false_negatives": int(private["stale_false_negatives"]),
            "false_invalidations": int(private["false_invalidations"]),
            "stratum_macro_f1": private["stratum_macro_f1"],
        },
        "generalization": {
            "private_minus_development": absolute_change,
            "relative_change_vs_development": absolute_change / dev_score,
            "development_inside_private_95_interval": (
                float(private["bootstrap_95_interval"][0])
                <= dev_score
                <= float(private["bootstrap_95_interval"][1])
            ),
            "interpretation": "substantial cross-domain generalization degradation",
        },
        "bootstrap": private["bootstrap"],
        "private_result_sha256": private["input_sha256"],
    }
    if args.output.exists():
        raise FileExistsError(f"summary already exists: {args.output}")
    temporary = args.output.with_suffix(args.output.suffix + ".tmp")
    temporary.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    temporary.replace(args.output)
    print(f"private_minus_development={absolute_change:.9f}")
    print(f"relative_change_vs_development={absolute_change / dev_score:.9%}")


if __name__ == "__main__":
    main()
