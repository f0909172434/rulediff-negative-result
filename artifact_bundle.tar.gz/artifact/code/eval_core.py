from __future__ import annotations

import math
import random
import re
from collections import Counter, defaultdict


STOPWORDS = {
    "a", "an", "and", "are", "as", "at", "be", "before", "for", "from", "if", "in", "is", "it", "of", "on", "or", "the", "this", "to", "user", "with"
}


def word_tokens(text: str) -> set[str]:
    return {token for token in re.findall(r"[a-z0-9]+", text.lower()) if token not in STOPWORDS}


def char_ngrams(text: str, n: int) -> set[str]:
    normalized = " ".join(re.findall(r"[a-z0-9]+", text.lower()))
    return {normalized[index:index + n] for index in range(max(0, len(normalized) - n + 1))}


def jaccard(left: set[str], right: set[str]) -> float:
    union = left | right
    return 0.0 if not union else len(left & right) / len(union)


def idf_weights(documents: list[set[str]]) -> dict[str, float]:
    counts: Counter[str] = Counter()
    for document in documents:
        counts.update(document)
    total = len(documents)
    return {token: math.log((1 + total) / (1 + frequency)) + 1.0 for token, frequency in counts.items()}


def weighted_cosine(left: set[str], right: set[str], weights: dict[str, float]) -> float:
    numerator = sum(weights.get(token, 1.0) ** 2 for token in left & right)
    left_norm = math.sqrt(sum(weights.get(token, 1.0) ** 2 for token in left))
    right_norm = math.sqrt(sum(weights.get(token, 1.0) ** 2 for token in right))
    return 0.0 if left_norm == 0.0 or right_norm == 0.0 else numerator / (left_norm * right_norm)


def similarity(method: str, artifact_text: str, transition_text: str, weights: dict[str, float], char_n: int, alpha: float) -> float:
    left_words, right_words = word_tokens(artifact_text), word_tokens(transition_text)
    if method == "word_jaccard":
        return jaccard(left_words, right_words)
    word_cosine = weighted_cosine(left_words, right_words, weights)
    if method == "word_idf_cosine":
        return word_cosine
    char_score = jaccard(char_ngrams(artifact_text, char_n), char_ngrams(transition_text, char_n))
    if method == "char_jaccard":
        return char_score
    if method == "hybrid":
        return alpha * word_cosine + (1.0 - alpha) * char_score
    raise ValueError(f"unknown method: {method}")


def binary_macro_f1(rows: list[dict[str, object]]) -> float:
    tp = sum(bool(row["truth"]) and bool(row["prediction"]) for row in rows)
    fp = sum(not bool(row["truth"]) and bool(row["prediction"]) for row in rows)
    fn = sum(bool(row["truth"]) and not bool(row["prediction"]) for row in rows)
    tn = len(rows) - tp - fp - fn

    def f1(a: int, b: int, c: int) -> float:
        denominator = 2 * a + b + c
        return 0.0 if denominator == 0 else 2 * a / denominator

    return (f1(tp, fp, fn) + f1(tn, fn, fp)) / 2


def summarize(rows: list[dict[str, object]], expected_strata: set[str] | None = None) -> dict[str, object]:
    strata: dict[str, list[dict[str, object]]] = defaultdict(list)
    for row in rows:
        strata[str(row["stratum"])].append(row)
    if expected_strata is not None and set(strata) != expected_strata:
        missing = sorted(expected_strata - set(strata))
        extra = sorted(set(strata) - expected_strata)
        raise ValueError(f"stratum mismatch missing={missing} extra={extra}")
    stratum_scores = {name: binary_macro_f1(values) for name, values in sorted(strata.items())}
    return {
        "pairs": len(rows),
        "transitions": len({str(row["transition_id"]) for row in rows}),
        "pooled_macro_f1": binary_macro_f1(rows),
        "stratified_macro_f1": sum(stratum_scores.values()) / len(stratum_scores),
        "stratum_macro_f1": stratum_scores,
        "stale_false_negatives": sum(bool(row["truth"]) and not bool(row["prediction"]) for row in rows),
        "false_invalidations": sum(not bool(row["truth"]) and bool(row["prediction"]) for row in rows),
    }


def evaluate(
    artifacts: list[dict[str, object]],
    transitions: list[dict[str, object]],
    method: str,
    threshold: float,
    char_n: int,
    alpha: float,
) -> dict[str, object]:
    documents = [word_tokens(str(row["artifact_text"])) for row in artifacts]
    documents.extend(word_tokens(str(row["old_clause"]) + " " + str(row["new_clause"])) for row in transitions)
    weights = idf_weights(documents)
    rows: list[dict[str, object]] = []
    for transition in transitions:
        affected = set(transition["affected_artifact_ids"])
        impact_fanout = len(affected)
        transition_text = str(transition["old_clause"]) + " [POLICY UPDATE] " + str(transition["new_clause"])
        for artifact in artifacts:
            value = similarity(method, str(artifact["artifact_text"]), transition_text, weights, char_n, alpha)
            rows.append(
                {
                    "transition_id": transition["transition_id"],
                    "source_clause_sha256": transition["source_clause_sha256"],
                    "shift_class": transition["shift_class"],
                    "impact_fanout": impact_fanout,
                    "stratum": f"{transition['shift_class']}|fanout={impact_fanout}",
                    "artifact_id": artifact["artifact_id"],
                    "truth": artifact["artifact_id"] in affected,
                    "prediction": value >= threshold,
                    "score": value,
                }
            )
    result = summarize(rows)
    result["rows"] = rows
    return result


def block_bootstrap_ci(rows: list[dict[str, object]], draws: int = 2000, seed: int = 20260929) -> tuple[float, float]:
    by_source: dict[str, list[dict[str, object]]] = defaultdict(list)
    for row in rows:
        by_source[str(row["source_clause_sha256"])].append(row)
    # Resample complete three-rewrite source-clause blocks. Stratifying by each
    # block's class/fan-out signature preserves the point estimand's strata.
    sources_by_signature: dict[tuple[tuple[str, int], ...], list[str]] = defaultdict(list)
    for source_id, source_rows in by_source.items():
        signature = tuple(sorted({(str(row["shift_class"]), int(row["impact_fanout"])) for row in source_rows}))
        sources_by_signature[signature].append(source_id)
    expected_strata = {str(row["stratum"]) for row in rows}
    rng = random.Random(seed)
    values: list[float] = []
    for _ in range(draws):
        sampled: list[dict[str, object]] = []
        for source_ids in sources_by_signature.values():
            ids = sorted(source_ids)
            for _ in ids:
                sampled.extend(by_source[rng.choice(ids)])
        values.append(float(summarize(sampled, expected_strata)["stratified_macro_f1"]))
    values.sort()
    return values[int(0.025 * draws)], values[min(draws - 1, int(0.975 * draws))]
