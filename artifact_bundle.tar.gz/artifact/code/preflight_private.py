from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter
from pathlib import Path


FROZEN_CONFIG = {
    "method": "word_idf_cosine",
    "threshold": 0.2,
    "char_n": 4,
    "alpha": 0.5,
}
SHIFT_CLASSES = {
    "tightened_prohibition",
    "relaxed_permission",
    "conditional_exception",
}


def load(path: Path) -> object:
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description="Non-scoring preflight for the one-shot G3 evaluation.")
    parser.add_argument("--winner", type=Path, required=True)
    parser.add_argument("--artifacts", type=Path, required=True)
    parser.add_argument("--test-inputs", type=Path, required=True)
    parser.add_argument("--private-labels", type=Path, required=True)
    parser.add_argument("--dev-inputs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    assert not args.output.exists(), f"private output already exists: {args.output}"
    winner = load(args.winner)
    assert isinstance(winner, dict) and winner.get("config") == FROZEN_CONFIG
    artifacts = load(args.artifacts)
    public_payload = load(args.test_inputs)
    private_payload = load(args.private_labels)
    dev_payload = load(args.dev_inputs)
    assert isinstance(artifacts, list) and artifacts
    assert isinstance(public_payload, dict) and isinstance(public_payload.get("transitions"), list)
    assert isinstance(private_payload, dict) and isinstance(private_payload.get("labels"), dict)
    assert isinstance(dev_payload, dict) and isinstance(dev_payload.get("transitions"), list)

    artifact_ids = [row["artifact_id"] for row in artifacts]
    assert len(artifact_ids) == len(set(artifact_ids))
    transitions = public_payload["transitions"]
    labels = private_payload["labels"]
    transition_ids = [row["transition_id"] for row in transitions]
    assert len(transitions) == 18 and len(transition_ids) == len(set(transition_ids))
    assert set(transition_ids) == set(labels)
    assert {row["shift_class"] for row in transitions} == SHIFT_CLASSES
    assert Counter(row["shift_class"] for row in transitions) == Counter({name: 6 for name in SHIFT_CLASSES})

    by_source: dict[str, set[str]] = {}
    for row in transitions:
        expected_hash = hashlib.sha256(row["old_clause"].encode("utf-8")).hexdigest()
        assert row["source_clause_sha256"] == expected_hash
        by_source.setdefault(expected_hash, set()).add(row["shift_class"])
        affected = labels[row["transition_id"]]["affected_artifact_ids"]
        assert affected and set(affected) <= set(artifact_ids)
    assert len(by_source) == 6 and all(classes == SHIFT_CLASSES for classes in by_source.values())

    dev_sources = {row["source_clause_sha256"] for row in dev_payload["transitions"]}
    assert not (set(by_source) & dev_sources), "private source-clause overlap with development"
    print(f"PASS artifacts={len(artifacts)} transitions={len(transitions)} pairs={len(artifacts) * len(transitions)}")
    for name, path in (
        ("winner", args.winner),
        ("artifacts", args.artifacts),
        ("test_inputs", args.test_inputs),
        ("private_labels", args.private_labels),
    ):
        print(f"sha256.{name}={sha256(path)}")


if __name__ == "__main__":
    main()
