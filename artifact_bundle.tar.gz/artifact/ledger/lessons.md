# mlsys2027_rulediff_local_v3: lessons

- 2026-09-29 04:59 (Frozen word-Jaccard baseline): The unified scratch-backed study root resolves the repaired local scheduler correctly and produces tracked metrics plus delivered artifacts.

- 2026-09-29 04:59 (IDF-weighted word cosine): IDF weighting is the dominant representation change on this development set; remaining runs should quantify threshold sensitivity and orthogonal alternatives.

- 2026-09-29 05:00 (Hybrid lexical similarity): The broad hybrid improves over uniform Jaccard but does not match IDF-only cosine.

- 2026-09-29 05:00 (Character four-gram overlap): Subword overlap alone over-invalidates or lacks sufficient specificity relative to word-level methods.

- 2026-09-29 05:01 (IDF cosine lower threshold 0.10): The IDF method is threshold-sensitive below 0.15.

- 2026-09-29 05:01 (IDF cosine threshold 0.12): The lower-side sensitivity curve supports a decision boundary near or above 0.15.

- 2026-09-29 05:02 (IDF cosine threshold 0.18): Raising the IDF decision threshold from 0.15 to 0.18 sharply reduces false invalidations on development data and materially improves stratified macro-F1.

- 2026-09-29 05:03 (IDF cosine threshold 0.20): The development optimum continues upward through threshold 0.20, but the tiny eight-source block sample makes the degenerate bootstrap interval non-generalizable.

- 2026-09-29 05:03 (IDF cosine threshold 0.25): The tested development optimum is bracketed between 0.18 and 0.25, with 0.20 best among evaluated thresholds.

- 2026-09-29 05:03 (Word-Jaccard threshold 0.10): The original Jaccard baseline is under-thresholded, yet representation weighting remains materially beneficial after calibrating Jaccard.

- 2026-09-29 05:04 (IDF-heavy hybrid): Character overlap adds no development value once IDF cosine is calibrated.

- 2026-09-29 05:04 (Character trigram overlap): Character n-gram overlap is decisively ruled out as a standalone method in the tested 3-gram and 4-gram settings.
