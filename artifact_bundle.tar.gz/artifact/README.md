# RuleDiff Reproducibility Artifact

This bundle accompanies the MLSys 2027 draft *When 0.99 Becomes 0.67: A Confirmatory Failure of Lexical Policy-Impact Prediction*. It reproduces the 12-configuration development ledger and independently recomputes the terminal G3 aggregate from released labels. The G3 recomputation is post-unblinding artifact validation, not a second blind test and not a replacement for the timestamped result in `results/private/private_result.json`.

## Quick Start

Requirements are Python 3.11 or newer, one CPU, less than 1 GiB RAM, and no network access. The implementation uses only the Python standard library.

```bash
python3 verify_artifact.py
```

Expected final line:

```text
ARTIFACT_VERIFICATION_PASS
```

The verifier checks the manifest, runs five unit tests, confirms all 12 ledger entries and configurations, recomputes every development aggregate, and independently recomputes the G3 score, error counts, strata, and seeded 2,000-draw confidence interval. Typical runtime is under one minute on a laptop CPU.

## Inventory

- `code/`: evaluator, development entry point, original one-shot G3 protocol, and post-hoc analysis.
- `data/development/`: 18 airline guard artifacts and 24 labeled rewrites from eight source clauses.
- `data/private/`: 12 retail guard artifacts, 18 rewrites from six source clauses, and terminal labels released only after G3.
- `ledger/`: all 12 adaptive development decisions and the authoritative TSV ledger.
- `results/development/`: one output per development configuration.
- `results/private/`: terminal G3 aggregate, comparison summary, and post-hoc failure analysis.
- `provenance/`: frozen policy snapshots and ToolGuard oracle records used to construct the benchmark.
- `licenses/`: project and third-party licenses plus source provenance.
- `run_manifest.json`: machine-readable commands, configurations, expected scores, and output paths.
- `MANIFEST.sha256`: checksums for all package files except itself.

## Reproduction Scope

The development ledger is an adaptive search over 12 configurations on one fixed benchmark, not 12 random seeds. Floating-point row scores can vary at approximately `1e-16` because the original implementation sums Python sets. The verifier therefore requires exact classifications and aggregate metrics, while allowing `1e-12` absolute tolerance for row scores.

The terminal G3 result is stratified macro-F1 `0.6660904423669545`, with a source-block percentile bootstrap 95% interval `[0.5795067378591406, 0.7152119519362252]`. It contains 14 affected-artifact false negatives and three false positives. The development winner is `word_idf_cosine` at threshold `0.20`, with development stratified macro-F1 `0.9919311457772997`.

## Data Release

All benchmark examples are policy-derived synthetic annotations; the bundle contains no user records, credentials, or observed personal data. The private labels are now public because G3 is terminal. They must not be used to claim a replacement confirmatory score. Any model revised after inspecting them requires a new independently held-out test.

## Exclusions

The package intentionally excludes the compromised airline private set, preliminary pilot, failed remote studies, and obsolete study roots. These cannot support the paper's confirmatory claims.

## Licensing

Author-created code and annotations are MIT licensed. The tau-bench policy text is redistributed under MIT. ToolGuard-derived oracle records retain Apache-2.0 terms. See `licenses/NOTICE.md`.
