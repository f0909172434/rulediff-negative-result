from __future__ import annotations

import argparse
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path


FROZEN_CONFIG = {
    "method": "word_idf_cosine",
    "threshold": 0.2,
    "char_n": 4,
    "alpha": 0.5,
}
BOOTSTRAP_DRAWS = 2000
BOOTSTRAP_SEED = 20260929


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description="One-shot aggregate evaluation of a frozen RuleDiff configuration.")
    parser.add_argument("--study-root", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--artifacts", type=Path, required=True)
    parser.add_argument("--test-inputs", type=Path, required=True)
    parser.add_argument("--private-labels", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(f"one-shot output already exists: {args.output}")
    sys.path.insert(0, str(args.study_root.resolve()))
    from eval_core import block_bootstrap_ci, evaluate

    config_payload = json.loads(args.config.read_text(encoding="utf-8"))
    config = config_payload.get("config", config_payload)
    if config != FROZEN_CONFIG:
        raise ValueError(f"configuration is not the frozen G2 winner: {config!r}")
    artifacts = json.loads(args.artifacts.read_text(encoding="utf-8"))
    public = json.loads(args.test_inputs.read_text(encoding="utf-8"))["transitions"]
    private_payload = json.loads(args.private_labels.read_text(encoding="utf-8"))
    labels = private_payload["labels"]
    if {row["transition_id"] for row in public} != set(labels):
        raise ValueError("public/private test ID mismatch")
    transitions = []
    for row in public:
        label = labels[row["transition_id"]]
        transitions.append({**row, "affected_artifact_ids": label["affected_artifact_ids"]})
    result = evaluate(
        artifacts,
        transitions,
        config["method"],
        float(config["threshold"]),
        int(config.get("char_n", 4)),
        float(config.get("alpha", 0.5)),
    )
    lower, upper = block_bootstrap_ci(result["rows"], draws=BOOTSTRAP_DRAWS, seed=BOOTSTRAP_SEED)
    aggregate = {key: value for key, value in result.items() if key != "rows"}
    aggregate.update(
        {
            "split": "private_test",
            "bootstrap_95_interval": [lower, upper],
            "candidate_config": config,
            "source_commit": private_payload["source_commit"],
            "label_access": "private evaluator only; pair rows and labels omitted",
            "bootstrap": {
                "unit": "source_clause_sha256 block",
                "draws": BOOTSTRAP_DRAWS,
                "seed": BOOTSTRAP_SEED,
                "interval": "percentile",
                "confidence_level": 0.95,
            },
            "input_sha256": {
                "config": sha256(args.config),
                "artifacts": sha256(args.artifacts),
                "test_inputs": sha256(args.test_inputs),
                "private_labels": sha256(args.private_labels),
                "eval_core": sha256(args.study_root / "eval_core.py"),
            },
            "evaluated_at_utc": datetime.now(timezone.utc).isoformat(),
        }
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    temporary = args.output.with_suffix(args.output.suffix + ".tmp")
    temporary.write_text(json.dumps(aggregate, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    temporary.replace(args.output)
    print(f"test_stratified_macro_f1={aggregate['stratified_macro_f1']:.9f}")
    print(f"bootstrap_95_interval=[{lower:.9f}, {upper:.9f}]")


if __name__ == "__main__":
    main()
