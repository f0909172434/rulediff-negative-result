# Data Specification

## Guard artifacts

Each artifact JSON array contains objects with a unique string `artifact_id` and string `artifact_text`. Optional descriptive fields do not enter scoring. A guard artifact is the unit whose validity may change after a policy rewrite.

## Policy transitions

Each transition has `transition_id`, `old_clause`, `new_clause`, `shift_class`, `source_clause_sha256`, and `affected_artifact_ids`. The allowed shift classes are `tightened_prohibition`, `relaxed_permission`, and `conditional_exception`. The SHA-256 value is computed from the exact UTF-8 bytes of `old_clause`.

The public private-test input omits `affected_artifact_ids`; `private_labels.json` maps each transition ID to that list. Post-G3 verification joins these records by exact transition ID.

## Evaluation rows

The evaluator forms the Cartesian product of transitions and artifacts. `truth` is whether an artifact ID appears in the transition's affected list. `prediction` is whether lexical similarity is at least the configured threshold. `impact_fanout` is the number of affected artifacts, and the stratum key is `<shift_class>|fanout=<impact_fanout>`.

Binary macro-F1 averages the positive-class and negative-class F1 values. Stratified macro-F1 averages binary macro-F1 uniformly over observed strata. A stale false negative is an affected artifact predicted unaffected; this is a classification miss, not an observed unsafe execution.

## Bootstrap

Confidence intervals use 2,000 percentile bootstrap draws with seed `20260929`. Complete source-clause blocks are sampled within class/fan-out signatures. The six-block private packet contains one high-fan-out signature represented by a single source clause, so the bootstrap does not estimate uncertainty for variation among high-fan-out clauses.
